package com.mind.simplelogin;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class teacherlayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacherlayout);
    }
}
